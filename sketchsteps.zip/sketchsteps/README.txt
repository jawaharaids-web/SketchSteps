SketchSteps

Open index.html in a browser. Single-file app (HTML, CSS, JS).
UPI ID and price are set near the top of the <script> block (UPI, LINK).
Credits are stored in localStorage (per browser). Payments are not verified without a backend.
